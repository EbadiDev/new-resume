import ConsultlyLogo from "./consultly.svg";
import AmbitLogo from "./ambit.png";
import BarepapersLogo from "./barepapers.svg";
import BimLogo from "./bim.png";
import CDGOLogo from "./cdgo.png";
import ClevertechLogo from "./clevertech.png";
import EvercastLogo from "./evercast.svg";
import Howdy from "./howdy.png";
import JarockiMeLogo from "./jarocki.svg";
import JojoMobileLogo from "./jojomobile.png";
import MonitoLogo from "./monito.svg";
import MobileVikingsLogo from "./mv.png";
import NSNLogo from "./nsn.svg";
import ParabolLogo from "./parabol.svg";
import TastyCloudLogo from "./tastycloud.png";
import YearProgressLogo from "./yearprogress.svg";
import Minimal from "./minimal.svg";

export {
  ConsultlyLogo,
  AmbitLogo,
  BarepapersLogo,
  BimLogo,
  CDGOLogo,
  ClevertechLogo,
  EvercastLogo,
  Howdy,
  JarockiMeLogo,
  JojoMobileLogo,
  MonitoLogo,
  MobileVikingsLogo,
  NSNLogo,
  ParabolLogo,
  TastyCloudLogo,
  YearProgressLogo,
  Minimal,
};
